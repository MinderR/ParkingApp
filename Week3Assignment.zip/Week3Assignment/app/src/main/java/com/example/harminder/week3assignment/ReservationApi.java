package com.example.harminder.week3assignment;

import com.example.harminder.week3assignment.model.Reservation;
import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by Harminder on 04/03/2018.
 */

public interface ReservationApi {

    String BASE_URL = "http://ridecellparking.herokuapp.com/";

    @GET("/jokes/random/500")
    Call<Reservation> isIs_reserved();

}
